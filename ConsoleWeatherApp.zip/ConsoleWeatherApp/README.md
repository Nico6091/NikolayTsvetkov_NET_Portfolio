# 🌦️ ConsoleWeatherApp

Конзолно приложение за извличане на текущото време за избран град чрез OpenWeatherMap API.

## 🚀 Стартиране
```bash
dotnet run
```

## 🔑 Необходимо е да добавите ваш API ключ от https://openweathermap.org

## 🧠 Технологии
- .NET Console App
- HttpClient
- JSON парсинг с System.Text.Json

## 🏗️ Архитектура

```mermaid
graph TD
    A[User] --> B[Console Input]
    B --> C[OpenWeatherMap API]
    C --> D[Json Parsing]
    D --> E[Console Output]
```

## 📸 Примерен изход
```
Въведи град: Sofia
🌤️ Времето в Sofia: 23.5°C
Описание: ясно небе
```

using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text.Json;

class Program
{
    static async Task Main()
    {
        Console.Write("Въведи град: ");
        string city = Console.ReadLine();

        string apiKey = "your_api_key";
        string url = $"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={apiKey}&units=metric&lang=bg";

        using HttpClient client = new HttpClient();
        var response = await client.GetStringAsync(url);

        var weather = JsonDocument.Parse(response).RootElement;
        Console.WriteLine($"
🌤️ Времето в {city}: {weather.GetProperty("main").GetProperty("temp")}°C");
        Console.WriteLine($"Описание: {weather.GetProperty("weather")[0].GetProperty("description").GetString()}");
    }
}

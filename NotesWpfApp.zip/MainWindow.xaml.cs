using System.Windows;

namespace NotesWpfApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddNote_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(noteInput.Text))
            {
                notesList.Items.Add(noteInput.Text);
                noteInput.Clear();
            }
        }
    }
}

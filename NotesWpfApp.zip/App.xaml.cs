using System.Windows;

namespace NotesWpfApp
{
    public partial class App : Application
    {
    }
}

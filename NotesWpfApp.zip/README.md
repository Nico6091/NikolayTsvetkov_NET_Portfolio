# 📝 NotesWpfApp

Просто WPF приложение за добавяне и преглед на бележки.

## 🧰 Технологии
- .NET 6
- WPF
- C#

## ▶️ Стартиране
```bash
cd NotesWpfApp
dotnet run
```

## 🛠️ Архитектура
```mermaid
flowchart TD
    UI["MainWindow.xaml"] --> CodeBehind["MainWindow.xaml.cs"]
    CodeBehind --> ListBox["ListBox: notesList"]
```

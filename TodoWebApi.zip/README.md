# 📝 TodoWebApi

Минимално ASP.NET Core Web API за управление на задачи (todo items) в паметта.

## 🎯 Цели на проекта
- Демонстрира основни REST CRUD операции
- Използва ASP.NET Core 6 minimal API структура

## 🧰 Технологии
- .NET 6
- ASP.NET Core Web API

## ▶️ Стартиране
```bash
cd TodoWebApi
dotnet run
```

API ще бъде достъпен на: `https://localhost:5001/api/todo` (или `http://localhost:5000/api/todo`)

## 💡 Примери за използване с curl

- Вземи всички задачи  
  `curl https://localhost:5001/api/todo`

- Добави задача  
  `curl -X POST -H "Content-Type: application/json" -d "{"title":"Нова задача","isCompleted":false}" https://localhost:5001/api/todo`

- Обнови задача  
  `curl -X PUT -H "Content-Type: application/json" -d "{"id":1,"title":"Променена задача","isCompleted":true}" https://localhost:5001/api/todo/1`

- Изтрий задача  
  `curl -X DELETE https://localhost:5001/api/todo/1`
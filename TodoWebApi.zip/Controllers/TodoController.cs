using Microsoft.AspNetCore.Mvc;
using TodoWebApi.Models;
using System.Collections.Generic;
using System.Linq;

namespace TodoWebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TodoController : ControllerBase
    {
        private static List<TodoItem> TodoItems = new List<TodoItem>();
        private static int nextId = 1;

        [HttpGet]
        public ActionResult<List<TodoItem>> GetAll()
        {
            return TodoItems;
        }

        [HttpGet("{id}")]
        public ActionResult<TodoItem> GetById(int id)
        {
            var item = TodoItems.FirstOrDefault(t => t.Id == id);
            if (item == null) return NotFound();
            return item;
        }

        [HttpPost]
        public ActionResult<TodoItem> Create(TodoItem newItem)
        {
            newItem.Id = nextId++;
            TodoItems.Add(newItem);
            return CreatedAtAction(nameof(GetById), new { id = newItem.Id }, newItem);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, TodoItem updatedItem)
        {
            var item = TodoItems.FirstOrDefault(t => t.Id == id);
            if (item == null) return NotFound();

            item.Title = updatedItem.Title;
            item.IsCompleted = updatedItem.IsCompleted;

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var item = TodoItems.FirstOrDefault(t => t.Id == id);
            if (item == null) return NotFound();

            TodoItems.Remove(item);
            return NoContent();
        }
    }
}
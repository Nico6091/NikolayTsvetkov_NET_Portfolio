using System;

namespace EGNValidatorApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете ЕГН: ");
            string egn = Console.ReadLine();

            if (EGNValidator.IsValid(egn))
                Console.WriteLine("ЕГН е валидно ✅");
            else
                Console.WriteLine("Невалидно ЕГН ❌");
        }
    }
}

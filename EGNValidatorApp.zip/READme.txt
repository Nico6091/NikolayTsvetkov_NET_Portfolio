# 🧪 EGNValidatorApp

Конзолно .NET приложение за валидиране на ЕГН (Единен Граждански Номер) по алгоритъма за контролна цифра.

## 🎯 Цели на проекта
- Демонстрация на основни C# концепции: класове, методи, масиви и проверки
- Реално приложение за валидация на потребителски вход
- Работа с .NET Console Application

## 🧰 Използвани технологии
- .NET 6
- C# 10

## ▶️ Стартиране на приложението
```bash
cd EGNValidatorApp
dotnet run

EGNValidatorApp/
├── Program.cs         # Основен входен файл
├── EGNValidator.cs    # Клас за валидация на ЕГН
└── README.md          # Този файл

flowchart TD
    Main["Program.cs"] --> Validator["EGNValidator.cs"]
    Validator --> Output["Console Output"]

Въведете ЕГН: 6101057509
ЕГН е валидно ✅


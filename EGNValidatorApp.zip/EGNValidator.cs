namespace EGNValidatorApp
{
    public static class EGNValidator
    {
        public static bool IsValid(string egn)
        {
            if (egn.Length != 10 || !long.TryParse(egn, out _))
                return false;

            int[] weights = {2, 4, 8, 5, 10, 9, 7, 3, 6};
            int checksum = 0;
            for (int i = 0; i < 9; i++)
                checksum += (egn[i] - '0') * weights[i];

            int remainder = checksum % 11;
            int controlDigit = remainder < 10 ? remainder : 0;

            return controlDigit == (egn[9] - '0');
        }
    }
}
